package org.izv.archivosdevinos;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.izv.archivosdevinos.data.Vino;
import org.izv.archivosdevinos.util.Fichero;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Fichero fichero;

    private Button btAdd, btEdit;
    private EditText etMainId;
    private TextView tvScroll;

    private List<Vino> listaVinos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }

    private void initialize() {
        fichero = new Fichero();

        tvScroll = findViewById(R.id.tvScroll);
        btEdit = findViewById(R.id.btEdit);
        btAdd = findViewById(R.id.btAdd);
        etMainId = findViewById(R.id.etMainId);

        // Cargamos la lista de vinos desde el fichero
        listaVinos = fichero.readFile(getFilesDir());

        if(listaVinos.size() > 0) {
            tvScroll.setText(visualizaList(listaVinos));
        }else {
            tvScroll.setText("");
        }

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSecondActivity();
            }
        });

        btEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etMainId.length() > 0) {
                    if(existeVino(listaVinos)) {
                        openThirdActivity();
                    }
                    else{
                        Snackbar.make(view,"El Id escrito no existe", Snackbar.LENGTH_SHORT).show();
                    }
                }
            }});
    }

    private void openSecondActivity() {
        Intent intent = new Intent(MainActivity.this, SecondActivity.class);
        startActivity(intent);
    }

    //Almacena el id del vino que pide editar y se la pasa al ThirdActivity
    public void openThirdActivity(){
        Intent intent = new Intent(this, ThirdActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("valor", etMainId.getText().toString());
        intent.putExtras(bundle);
        startActivity(intent);
    }

    //Visualiza la lista de vinos en el MainActivity
    public String visualizaList(List<Vino> listVinos) {
        String texto = "";
        for(int i = 0;i < listVinos.size();i++) {
            texto += listVinos.get(i).getId() + "; " + listVinos.get(i).getNombre() + "; " + listVinos.get(i).getBodega() + "; " + listVinos.get(i).getOrigen() + "; " + listVinos.get(i).getColor() + "; " + listVinos.get(i).getGraduacion() + "; " + listVinos.get(i).getFecha() + '\n'+'\n';
        }
        return texto;
    }

    //Comprobamos si existe un vino
    public  boolean existeVino(List<Vino> listVinos){
        for(int i=0;i <listVinos.size();i++){
            if(listVinos.get(i).getId() == Long.parseLong(etMainId.getText().toString())){
                return true;
            }
        }
        return false;
    }

}