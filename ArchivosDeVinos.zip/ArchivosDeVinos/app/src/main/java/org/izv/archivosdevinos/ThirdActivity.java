package org.izv.archivosdevinos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.izv.archivosdevinos.data.Vino;
import org.izv.archivosdevinos.util.Fichero;

import java.util.List;

public class ThirdActivity extends AppCompatActivity {

    private Fichero fichero;

    private List<Vino> listaVinos;

    private Bundle bundle;

    private Button btSecEdit, btDelete, btCancel;
    private EditText etNombre, etBodega, etColor, etOrigen, eTGraduacion, eTFecha;
    private TextView tvIdFijo;

    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        initialize();
    }

    private void initialize() {
        fichero = new Fichero();

        listaVinos = fichero.readFile(getFilesDir());

        bundle = getIntent().getExtras();

        btSecEdit = findViewById(R.id.btSecEdit);
        btDelete = findViewById(R.id.btDelete);
        btCancel = findViewById(R.id.btCancel);

        tvIdFijo = findViewById(R.id.tvIdFijo);
        etNombre = findViewById(R.id.etNombre);
        etBodega = findViewById(R.id.etBodega);
        etColor = findViewById(R.id.etColor);
        etOrigen = findViewById(R.id.etOrigen);
        eTGraduacion = findViewById(R.id.etGraduacion);
        eTFecha = findViewById(R.id.etFecha);

        // Recibimos el Id del vino a editar desde la MainActivity mediante el bundle
        id = Integer.parseInt(bundle.getString("valor"));

        // Visualiza el Id del vino recibido en el EditText del Id del MainActivity
        tvIdFijo.setText(String.valueOf(id));
        // Carga los datos del vino a editar
        rellenaEditTexts();

        btSecEdit.setOnClickListener(view -> {
            guardaListaVinos(editaVino());
            Intent intent = new Intent(ThirdActivity.this, MainActivity.class);
            startActivity(intent);
        });


        btDelete.setOnClickListener(view -> {
            guardaListaVinos(borraVino());
            Intent intent = new Intent(ThirdActivity.this, MainActivity.class);
            startActivity(intent);
        });


        btCancel.setOnClickListener(view -> {
            Intent intent = new Intent(ThirdActivity.this, MainActivity.class);
            startActivity(intent);
        });

    }

    // Método que carga en los EditText los datos del vino a editar
    public void rellenaEditTexts(){
        // Si existe el vino carga en la posicion i de la lista de vinos los datos del vino
        if(buscaVino() != -1) {
            int i = buscaVino();
            etNombre.setText(listaVinos.get(i).getNombre());
            etBodega.setText(listaVinos.get(i).getBodega());
            etColor.setText(listaVinos.get(i).getColor());
            etOrigen.setText(listaVinos.get(i).getOrigen());
            eTGraduacion.setText(String.valueOf(listaVinos.get(i).getGraduacion()));
            eTFecha.setText(String.valueOf(listaVinos.get(i).getFecha()));
        }
    }

    // Método que actualiza los datos del vino indicado
    public List<Vino> editaVino(){
        // En la lista de vinos indica la posicion del vino a actualizar
        if(buscaVino() != -1) {
            int i = buscaVino();
            listaVinos.get(i).setNombre(etNombre.getText().toString());
            listaVinos.get(i).setBodega(etBodega.getText().toString());
            listaVinos.get(i).setColor(etColor.getText().toString());
            listaVinos.get(i).setOrigen(etOrigen.getText().toString());

            try {
                listaVinos.get(i).setGraduacion(Double.parseDouble(eTGraduacion.getText().toString()));
            } catch (NumberFormatException e) {
                e.getMessage();
            }

            try {
                listaVinos.get(i).setFecha(Integer.parseInt(eTFecha.getText().toString()));
            }catch (NumberFormatException e) {
                e.getMessage();
            }
        }
        return listaVinos;
    }

    // Método que guarda la lista de vinos en el archivo.csv
    public void guardaListaVinos(List<Vino> listaVinos){
        // Elimina el archivo.csv
        fichero.deleteFile(getFilesDir());
        // Escribe la lista de vinos en un nuevo archivo.csv
        for(int i= 0;i < listaVinos.size();i++){
            fichero.writeFile(getFilesDir(), Vino.escribeVino(listaVinos.get(i)));
        }
    }

    // Elimina el vino indicado de la lista de vinos
    public List<Vino> borraVino(){
        // Si existe el vino buscado
        if(buscaVino() != -1) {
            int i = buscaVino();
            listaVinos.remove(i);
        }
        return listaVinos;
    }

    // Método para buscar si existe un vino en la lista de vinos
    public int buscaVino(){
        for(int i=0;i< listaVinos.size();i++){
            if(id == listaVinos.get(i).getId()){
                return i;
            }
        }
        //cuando no existe el vino
        return -1;
    }
}
