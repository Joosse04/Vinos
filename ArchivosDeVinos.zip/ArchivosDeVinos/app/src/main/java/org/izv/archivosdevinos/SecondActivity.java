package org.izv.archivosdevinos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

import org.izv.archivosdevinos.data.Vino;
import org.izv.archivosdevinos.util.Fichero;

import java.util.List;

public class SecondActivity extends AppCompatActivity {

    private Fichero fichero;

    private Intent intent;

    private Button btSecAdd, btCancel;
    private EditText etId, etNombre, etBodega, etColor, etOrigen, etGraduacion, etFecha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        initialize();
    }

    private void initialize() {
        fichero = new Fichero();

        intent = new Intent(SecondActivity.this, MainActivity.class);

        btSecAdd = findViewById(R.id.btSecAdd);
        btCancel = findViewById(R.id.btCancel);

        etId = findViewById(R.id.etId);
        etNombre = findViewById(R.id.etNombre);
        etBodega = findViewById(R.id.etBodega);
        etColor = findViewById(R.id.etColor);
        etOrigen = findViewById(R.id.etOrigen);
        etGraduacion = findViewById(R.id.etGraduacion);
        etFecha = findViewById(R.id.etFecha);

        etId.setText("");
        etNombre.setText("");
        etBodega.setText("");
        etColor.setText("");
        etOrigen.setText("");
        etGraduacion.setText("");
        etFecha.setText("");

        btSecAdd.setOnClickListener((View v) -> {
            if(existeVino()){
                Snackbar.make(v, "Ya existe un vino con ese Id", Snackbar.LENGTH_SHORT).show();
            }else if(editTextVacio()){
                Snackbar.make(v, "Hay algún/os EditText vacio/os", Snackbar.LENGTH_SHORT).show();
            }else {
                fichero.writeFile(getFilesDir(), Vino.escribeVino((creaVino())));
                startActivity(intent);
            }
        });

        btCancel.setOnClickListener((View v) -> {
            Intent intent = new Intent(SecondActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }

    // Método que crea un objeto vino con los datos obtenidos de los EditText
    public Vino creaVino(){
        Vino vino = new Vino();
        try {
            vino.setId(Long.parseLong(etId.getText().toString()));
        }catch(NumberFormatException e){
            e.getMessage();
        }

        vino.setNombre(etNombre.getText().toString());
        vino.setBodega(etBodega.getText().toString());
        vino.setColor(etColor.getText().toString());
        vino.setOrigen(etOrigen.getText().toString());

        try {
            vino.setGraduacion(Double.parseDouble(etGraduacion.getText().toString()));
        }catch(NumberFormatException e) {
            e.getMessage();
        }

        try {
            vino.setFecha(Integer.parseInt(etFecha.getText().toString()));
        }catch(NumberFormatException e) {
            e.getMessage();
        }
        return vino;
    }

    // Método que devuelve true si ya existe el Id del vino a crear
    public boolean existeVino(){
        List<Vino> listaVinos = fichero.readFile(getFilesDir());
        for(int i= 0;i < listaVinos.size();i++){
            if(Long.parseLong(etId.getText().toString()) == listaVinos.get(i).getId()){
                return true;
            }
        }
        return false;
    }

    // Método que devuelve si hay algún EditText vacío
    public boolean editTextVacio(){
        if(etId.getText().length() == 0 || etNombre.getText().length() == 0 || etBodega.getText().length() == 0 ||  etColor.getText().length() == 0 ||
                etOrigen.getText().length() == 0 || etGraduacion.getText().length() == 0 || etFecha.getText().length() == 0) {
            return true;
        }else{
            return false;
        }
    }
}
