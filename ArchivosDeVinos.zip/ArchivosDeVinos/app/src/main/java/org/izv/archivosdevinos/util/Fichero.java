package org.izv.archivosdevinos.util;

import android.util.Log;

import org.izv.archivosdevinos.MainActivity;
import org.izv.archivosdevinos.data.Vino;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Fichero {
    public static final String TAG = MainActivity.class.getName() + "xyzyx";
    public static final String fileName = "archivoJose.csv";

    public void writeFile(File file, String vino) {
        File f = new File(file, fileName);
        FileWriter fw = null;

        try {
            fw = new FileWriter(f, true);
            fw.write(vino);
            fw.write("\n");
            fw.flush();
            fw.close();
        } catch (IOException e) {
            Log.v(TAG, e.toString());
        }
    }

    // Lista de vinos desde el csv
    public List<Vino> readFile(File file){
        String linea = "";
        List<Vino> winelist = new ArrayList<>();
        File f = new File(file, fileName);
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            while ((linea = br.readLine()) != null) {
                winelist.add(Vino.leeVino(linea));
            }
            br.close();
        } catch(IOException e) {
        }
        return winelist;
    }

    public void deleteFile(File file) {
        File f = new File(file, fileName);
        f.delete();
    }
}
